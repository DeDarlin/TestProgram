#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <windows.h>

#undef byte
#include <string>
#include <fstream>
#include "TestProgram.h"
#include "Menu.h"
#include "md5.h"
#include "User.h"
#include "Admin.h"
#include "functions.h"
#include "utils.h"

bool TestProgram::UserExists(const std::string& login)
{
	std::ifstream in("Users.txt");
	if (!in) return false;

	std::string fileLogin;
	while (in >> fileLogin)
	{
		if (fileLogin == login)
			return true;

		std::string skip;
		std::getline(in, skip);
	}
	return false;
}


void TestProgram::SignIn()
{
	system("cls");
	std::string login, password;
	gotoxy(x, y);
	cout << "Введіть ПІБ: "; getline(cin, login);
	login = utils::RemoveSpaces(login);
	gotoxy(x, y + 1);
	cout << "Введіть пароль: "; getline(cin, password);

	ifstream in("Users.txt");
	if (!in.is_open())
	{
		system("cls");
		gotoxy(x, y);
		cout << "Файл не знайдено" << endl;
		Sleep(1000);
		return;
	}

	std::string temp_login, temp_password;
	bool flag = false;
	size_t s = static_cast<size_t>(-1);
	size_t i = 0;

	while (in >> temp_login >> temp_password)
	{
		if (temp_login == login && temp_password == md5(password))
		{
			flag = true;
			s = i;
			break;
		}
		++i;
	}
	in.close();

	if (!flag)
	{
		system("cls");
		gotoxy(x, y);
		cout << "Введені не вірні дані" << endl;
		Sleep(1000);
		return;
	}

	if (s == 0)
	{
		Admin admin(login, password);
		admin.menu();
	}
	else
	{
		User user(login, password);
		user.menu();
	}
}

void TestProgram::SignUp()
{
	system("cls");

	struct Abonent
	{
		std::string login;
		std::string password;
		std::string home_address;
		std::string mobile_number;
	};

	Abonent current;
	gotoxy(x, y);
	cout << "Введіть ПІБ: "; getline(cin, current.login);
	current.login = utils::RemoveSpaces(current.login);

	if (UserExists(current.login) == true)
	{
		system("cls");
		gotoxy(x, y);
		cout << "Аккаунт з таким ПІБ вже створений" << endl;
		Sleep(1000);
		return;
	}

	gotoxy(x, y + 1);
	cout << "Введіть пароль: "; getline(cin, current.password);
	gotoxy(x, y + 2);
	cout << "Введіть домашню адресу: "; getline(cin, current.home_address);
	gotoxy(x, y + 3);
	cout << "Введіть мобільний телефон: "; getline(cin, current.mobile_number);

	ofstream out("Users.txt", ios::app);
	out << current.login << " " << md5(current.password) << " " << current.home_address << " " << current.mobile_number << endl;
	out.close();

	system("cls");
	gotoxy(x, y);
	cout << "Реєстрація успішна" << endl;
	Sleep(1000);
}

void TestProgram::Run()
{
	while (true)
	{
		system("cls");
		int c = Menu::select_vertical({ "Вхід", "Реєстрація", "Вихід" }, HorizontalAlignment::Center, 12);
		switch (c)
		{
		case 0:
			SignIn();
			break;
		case 1:
			SignUp();
			break;
		case 2:
			exit(0);
		}
	}
}