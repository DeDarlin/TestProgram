#pragma once
#include <string>

class TestProgram
{

public:

	bool UserExists(const std::string& login);

	void SignIn();

	void SignUp();

	void Run();
};