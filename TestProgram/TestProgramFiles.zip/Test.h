#pragma once

class Test
{
	string current;

public:
	Test(string current) : current(current) {}

	void Delete();

	string start();
};