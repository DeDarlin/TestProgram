#include "utils.h"

std::string utils::RemoveSpaces(const std::string& s) {
	std::string out;
	out.reserve(s.size());
	for (char c : s) {
		if (c != ' ') out.push_back(c);
	}
	return out;
}
