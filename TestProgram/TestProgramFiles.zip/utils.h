#pragma once
#include <string>

namespace utils {
    std::string RemoveSpaces(const std::string& s);
}